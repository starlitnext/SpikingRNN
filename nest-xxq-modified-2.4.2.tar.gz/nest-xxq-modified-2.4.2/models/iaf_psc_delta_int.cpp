/*
 *  iaf_psc_delta_int.cpp
 *
 *  This file is part of NEST.
 *
 *  Copyright (C) 2004 The NEST Initiative
 *
 *  NEST is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  NEST is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with NEST.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

/* iaf_psc_delta_int is a neuron where the potential jumps on each spike arrival. */

#include "exceptions.h"
#include "iaf_psc_delta_int.h"
#include "network.h"
#include "dict.h"
#include "integerdatum.h"  
#include "doubledatum.h"
#include "dictutils.h"
#include "numerics.h"
#include "universal_data_logger_impl.h"

#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

using namespace std;

namespace
{

// Enforce bit width specification on an integer.
// 
// x: The integer.
// bitWidth: The desired bit width of the integer.
// Convert an integer so that only the bitWidth least significant bits are
// preserved. The other bits are set to the bit value of the most significant
// bit among the preserved bits to simulate sign-extention.
// 
// This function returns the integer after conversion.
inline int64_t enforceBitWidth(const int64_t x, const int bitWidth)
{
  const int bitWidthMax = 64;

  if(bitWidth <= 0 || bitWidth > bitWidthMax)
  {
    throw nest::BadProperty(
      "The expected bit width must be a positive integer.");
  }

  if(bitWidth == bitWidthMax)
    return x;
  // Extract the sign bit of the value.
  int64_t signBit = (x & (static_cast<int64_t>(1) << (bitWidth - 1)));
  int64_t mask;
  int64_t result;
  if(signBit == 0)
  {
    // The value is zero or positive.
    // Sign-extend with 0's.
    mask = ~(static_cast<int64_t>(-1) << bitWidth);
    result = (x & mask);
  }
  else
  {
    // The value is negative.
    // Sign-extend with 1's.
    mask = (static_cast<int64_t>(-1) << bitWidth);
    result = (x | mask);
  }
  return result;
}

// Shift an integer left or right by a number of bits.
// 
// x: The integer.
// shift: The shift amount. Positive shift amounts are interpreted as left shift
// amounts whereas negative ones as right shift amounts.
// 
// This function returns the integer produced by the shift.
inline int32_t shiftArithmetic(const int64_t x, const int shift)
{
  const int bitWidth = 64;
  if(shift == 0)
    return static_cast<int32_t>(x);
  if(shift > 0)
  {
    // Left shift
    if(shift >= bitWidth)
      return static_cast<int32_t>(0);
    else
      return static_cast<int32_t>(x << shift);
  }
  else
  {
    // Right shift
    if(shift <= -bitWidth)
      return static_cast<int32_t>(x >= 0 ? 0 : -1);
    else
    {
      int64_t result = (x >> (-shift));
      // Ensure arithmetic right shift is implemented.
      if(x < 0)
        result |= (static_cast<int64_t>(-1) << (bitWidth - (-shift)));
      return static_cast<int32_t>(result);
    }
  }
}

// Multiply an integer by a fixed-point value and cast the result to the same
// integer type as the integer.
// 
// x: The integer.
// significand: The significand of the fixed-point value.
// exponent: The exponent of the fixed-point value, which is also the shift
// amount to be applied to the product of x and significand. exponent should be
// positive if left shift is to be applied, and negative if right shift is to be
// applied.
// bitWidthX: The bit width of x.
// bitWidthSignificand: The bit width of significand.
// bitWidthResult: The expected bit width of the result. The sum is truncated to
// bitWidth bits, and then sign-extended.
// 
// This function returns the product after the shift.
// The shift is applied to the 64-bit product rather than to the lower 32 bits
// of the 64-bit product.
// Note that for a negative product, when the exponent is a large negative
// number, the result is -1 instead of 0.
int32_t multiplyByFixedPointValue(
  const int32_t x,
  const int32_t significand,
  const int exponent,
  const int bitWidthX,
  const int bitWidthSignificand,
  const int bitWidthResult)
{
  if(bitWidthX <= 0 || bitWidthSignificand <= 0)
    throw invalid_argument("Both the bit width of the integer and the bit width "
      "of the significand of the fixed-point value must be positive integers.");
  int64_t product = static_cast<int64_t>(x) * significand;
  // Note: For the product of x and significand, the sign bit is bit
  // (bitWidthX+bitWidthSignificand) instead of bit 63. Thus, enforceBitWidth is
  // called before the arithmetic shift to ensure the correct sign bit is used.
  int32_t productShifted = shiftArithmetic(
    enforceBitWidth(product, bitWidthX + bitWidthSignificand),
    exponent);
  return static_cast<int32_t>(enforceBitWidth(productShifted, bitWidthResult));
}

// Add two integer without causing overflow.
// 
// x0: A source operand.
// x1: The other source operand.
// bitWidth: The expected bit width of the result. The sum is truncated to
// bitWidth bits, and then sign-extended.
// 
// If no overflow occurs during the addition, x0 and x1 are added and the sum is
// returned. Otherwise, the integer with the largest possible absolute value as
// its absolute value and the same sign as the source operands is returned.
// Note that this function assumes that the bit width of the operands are equal
// to expected bit width of the result.
int32_t addWithoutOverflow(
  const int32_t x0,
  const int32_t x1,
  const int bitWidth)
{
  int32_t sum = enforceBitWidth(x0 + x1, bitWidth);
  if(x0 > 0 && x1 > 0 && sum < 0)
    return ~(static_cast<int32_t>(-1) << (bitWidth - 1));
  if(x0 < 0 && x1 < 0 && sum >= 0)
    return (static_cast<int32_t>(-1) << (bitWidth - 1));
  return sum;
}

}

namespace nest
{

  /* ---------------------------------------------------------------- 
   * Recordables map
   * ---------------------------------------------------------------- */

  RecordablesMap<iaf_psc_delta_int> iaf_psc_delta_int::recordablesMap_;

  // Override the create() method with one call to RecordablesMap::insert_() 
  // for each quantity to be recorded.
  template <>
  void RecordablesMap<iaf_psc_delta_int>::create()
  {
    // use standard names whereever you can for consistency!
    insert_(names::V_m, &iaf_psc_delta_int::get_V_m_);
  }

/* ---------------------------------------------------------------- 
 * Default constructors defining default parameters and state
 * ---------------------------------------------------------------- */

nest::iaf_psc_delta_int::Parameters_::Parameters_()
  : VBits_         (32),
    VdecBits_      (32),
    Vdec_sig_      (1),
    V_th_          (1),
    wBits_         (16),
    wAccBits_      (20),
    wAccShift_        (0),
    t_ref_         (2.0)  // ms
{}

nest::iaf_psc_delta_int::State_::State_()
  : y3_   (0.0),  
    r_    (0)
{}

/* ---------------------------------------------------------------- 
 * Parameter and state extractions and manipulation functions
 * ---------------------------------------------------------------- */

void nest::iaf_psc_delta_int::Parameters_::get(DictionaryDatum &d) const
{
  def<long>(d, names::VBits, VBits_);
  def<long>(d, names::VdecBits, VdecBits_);
  def<long>(d, names::Vdec_sig, Vdec_sig_);
  def<long>(d, names::V_th, V_th_);
  def<long>(d, names::wBits, wBits_);
  def<long>(d, names::wAccBits, wAccBits_);
  def<long>(d, names::wAccShift, wAccShift_);
  def<double_t>(d, names::t_ref, t_ref_);

  /*std::cout << "NEST: Returning parameters ..." << std::endl
    << names::VBits.toString() << ": " << VBits_ << std::endl
    << names::VdecBits.toString() << ": " << VdecBits_ << std::endl
    << names::Vdec_sig.toString() << ": " << Vdec_sig_ << std::endl
    << names::V_th.toString() << ": " << V_th_ << std::endl
    << names::wBits.toString() << ": " << wBits_ << std::endl
    << names::wAccBits.toString() << ": " << wAccBits_ << std::endl
    << names::wAccShift.toString() << ": " << wAccShift_ << std::endl
    << names::t_ref.toString() << ": " << t_ref_ << std::endl;*/
}

void nest::iaf_psc_delta_int::Parameters_::set(const DictionaryDatum& d)
{
  long tempInt;
  // VBits
  if(updateValue<long>(d, names::VBits, tempInt))
    VBits_ = static_cast<int_t>(tempInt);
  // VdecBits
  if(updateValue<long>(d, names::VdecBits, tempInt))
    VdecBits_ = static_cast<int_t>(tempInt);
  // Vdec_sig
  if(updateValue<long>(d, names::Vdec_sig, tempInt))
    Vdec_sig_ = static_cast<int32_t>(tempInt);
  // V_th
  if(updateValue<long>(d, names::V_th, tempInt))
    V_th_ = static_cast<int32_t>(tempInt);
  // wBits
  if(updateValue<long>(d, names::wBits, tempInt))
    wBits_ = static_cast<int_t>(tempInt);
  // wAccBits
  if(updateValue<long>(d, names::wAccBits, tempInt))
    wAccBits_ = static_cast<int_t>(tempInt);
  // wAccShift
  if(updateValue<long>(d, names::wAccShift, tempInt))
    wAccShift_ = static_cast<int_t>(tempInt);
  // t_ref
  updateValue<double>(d, names::t_ref, t_ref_);
  // Check parameters.
  // Ensure that there is at least one bit besides the sign bit and that the
  // bit width does not exceed the maximum bit width.
  int32_t tempInt32;
  if(VBits_ < 2 || VBits_ > BitWidthMax_)
  {
    throw BadProperty(
      "The bit width of membrane potential must be a positive integer and not "
      "exceed " + to_string(BitWidthMax_) + ".");
  }
  if(VdecBits_ < 2 || VdecBits_ > BitWidthMax_)
  {
    throw BadProperty(
      "The bit width the significand of the membrane potential decay ratio must "
      "be a positive integer and not exceed " + to_string(BitWidthMax_) + ".");
  }
  // Ensure that the values are not changed due to the limited bit widths.
  tempInt32 = static_cast<int32_t>(enforceBitWidth(Vdec_sig_, VdecBits_));
  if(Vdec_sig_ < 0 || tempInt32 != Vdec_sig_)
  {
    throw BadProperty(
      "The significand of the membrane potential decay ratio must be a positive "
      "integer within the range determined by its bit width.");
  }
  Vdec_sig_ = tempInt32;
  tempInt32 = static_cast<int32_t>(enforceBitWidth(V_th_, VBits_));
  if(V_th_ <= V_rest_ || tempInt32 != V_th_)
  {
    throw BadProperty(
      "The firing threshold must be a positive integer within the range "
      "determined by the bit width of membrane potential, and its value must be "
      "strictly above the resting potential " + to_string(V_rest_) + ".");
  }
  V_th_ = tempInt32;
  if(wBits_ < 2 || wBits_ > BitWidthMax_)
  {
    throw BadProperty(
      "The bit width of synaptic weights must be a positive integer and not "
      "exceed " + to_string(BitWidthMax_) + ".");
  }
  if(wAccBits_ < wBits_ || wAccBits_ > BitWidthMax_)
  {
    throw BadProperty(
      "The bit width of the synaptic weight accumulator must be a positive "
      "integer that is at least as large as the current bit width of synaptic "
      "weights and must not exceed " + to_string(BitWidthMax_) + ".");
  }
  // Aligning the least significant bit of weight accumulator values with the
  // sign bit of the membrane potential may not produce the desirable result.
  // Aligning the sign bit of weight accumulator values with the least
  // significant bit of the membrane potential means only 0 or -1 would be added
  // to the membrane potential, and no positive value may be added to the
  // membrane potential. (Note that shifting a negative weight accumulator value
  // to the right by more than (wAccBits-2) bits results in -1 due to
  // sign-extension.)
  // The upper bound and lower bound of the shift amount of weight accumulator
  // values are determined by considering the extreme cases where only the
  // two most-significant bits or the two least significant bits (including the
  // sign bit) of weight accumulator values are involved in the addition.
  if(wAccShift_ < -(wAccBits_ - 2) || wAccShift_ < -(BitWidthMax_ - 1) ||
    wAccShift_ > VBits_ - 2 || wAccShift_ > BitWidthMax_ - 1)
  {
    throw BadProperty(
      "The shift amount of weight accumulator values must be an integer within "
      "the range [-(wAccBits-2),VBits-2], where wAccBits and VBits are the bit "
      "width of the synaptic weight accumulator and the bit width of the "
      "membrane potential, respectively. Meanwhile, the shift amount must be an "
      "integer within the range [-(BitWidthMax-1),BitWidthMax-1], where "
      "BitWidthMax is currently " + to_string(BitWidthMax_) + ".");
  }
  if(t_ref_ < 0)
  {
    throw BadProperty(
      "The refractory period must be zero or a positive real number.");
  }
}

void nest::iaf_psc_delta_int::State_::get(DictionaryDatum &d, const Parameters_&) const
{
  def<long>(d, names::V_m, y3_); // Membrane potential
}

void nest::iaf_psc_delta_int::State_::set(const DictionaryDatum& d, const Parameters_& p)
{
  long tempInt;
  if(updateValue<long>(d, names::V_m, tempInt))
  {
    y3_ = static_cast<int32_t>(tempInt);
    // Ensure the bit width of membrane potential.
    int32_t Vtemp = static_cast<int32_t>(enforceBitWidth(y3_, p.VBits_));
    if(Vtemp != y3_)
      throw BadProperty(
        "The membrane potential must be an integer within the range determined "
        "by the bit width of membrane potential.");
  }
}

nest::iaf_psc_delta_int::Buffers_::Buffers_(iaf_psc_delta_int &n)
  : logger_(n)
{}

nest::iaf_psc_delta_int::Buffers_::Buffers_(const Buffers_ &, iaf_psc_delta_int &n)
  : logger_(n)
{}

/* ---------------------------------------------------------------- 
 * Default and copy constructor for node
 * ---------------------------------------------------------------- */

nest::iaf_psc_delta_int::iaf_psc_delta_int()
  : Archiving_Node(), 
    P_(), 
    S_(),
    B_(*this)
{
  recordablesMap_.create();
}

nest::iaf_psc_delta_int::iaf_psc_delta_int(const iaf_psc_delta_int& n)
  : Archiving_Node(n), 
    P_(n.P_), 
    S_(n.S_),
    B_(n.B_, *this)
{}

/* ---------------------------------------------------------------- 
 * Node initialization functions
 * ---------------------------------------------------------------- */

void nest::iaf_psc_delta_int::init_state_(const Node& proto)
{
  const iaf_psc_delta_int& pr = downcast<iaf_psc_delta_int>(proto);
  S_ = pr.S_;
}

void nest::iaf_psc_delta_int::init_buffers_()
{
  B_.spikes_.clear();       // includes resize
  B_.currents_.clear();        // includes resize
  B_.logger_.reset(); // includes resize
  Archiving_Node::clear_history();
}

void nest::iaf_psc_delta_int::calibrate()
{
  B_.logger_.init();

  // TauR specifies the length of the absolute refractory period as 
  // a double_t in ms. The grid based iaf_psp_delta can only handle refractory
  // periods that are integer multiples of the computation step size (h).
  // To ensure consistency with the overall simulation scheme such conversion
  // should be carried out via objects of class nest::Time. The conversion 
  // requires 2 steps:
  //     1. A time object r is constructed defining  representation of 
  //        TauR in tics. This representation is then converted to computation time
  //        steps again by a strategy defined by class nest::Time.
  //     2. The refractory time in units of steps is read out get_steps(), a member
  //        function of class nest::Time.
  //
  // The definition of the refractory period of the iaf_psc_delta_int is consistent 
  // the one of iaf_neuron_ps.                                         
  //
  // Choosing a TauR that is not an integer multiple of the computation time 
  // step h will leed to accurate (up to the resolution h) and self-consistent
  // results. However, a neuron model capable of operating with real valued spike
  // time may exhibit a different effective refractory time.
  //
  
  V_.RefractoryCounts_ = Time(Time::ms(P_.t_ref_)).get_steps();
  assert(V_.RefractoryCounts_ >= 0);  // since t_ref_ >= 0, this can only fail in error
}

/* ---------------------------------------------------------------- 
 * Update and spike handling functions
 */

void nest::iaf_psc_delta_int::update(Time const & origin, 
				 const long_t from, const long_t to)
{
  assert(to >= 0 && (delay) from < Scheduler::get_min_delay());
  assert(from < to);

  for ( long_t lag = from ; lag < to ; ++lag )
  {
    if ( S_.r_ == 0 )
    {
      // neuron not refractory
      // Multiply the membrane potential by the membrane potential decay ratio.
      S_.y3_ =
        multiplyByFixedPointValue(
          S_.y3_,
          P_.Vdec_sig_,
          -(P_.VdecBits_ - 1),
          P_.VBits_,
          P_.VdecBits_,
          P_.VBits_);
      // Increment the membrane potential according to the input.
      int64_t wAccLong = static_cast<int64_t>(B_.spikes_.get_value(lag));
      int32_t wAcc = static_cast<int32_t>(wAccLong);
      if(enforceBitWidth(wAcc, P_.wAccBits_) != wAccLong)
      {
        std::cout << "The synaptic weight accumulator overflows." << std::endl;
        std::cout.flush();
        // The synaptic weight accumulator overflows.
        // Set its value to the value with the maximum possible absolute value
        // and the same sign as the synaptic weight.
        int32_t temp = (static_cast<int32_t>(-1) << (P_.wAccBits_ - 1));
        wAcc = (wAcc >= 0 ? (~temp) : temp);
      }
      // Shift the weight accumulator value before adding it to the membrane
      // potential.
      wAcc = shiftArithmetic(wAcc, P_.wAccShift_);
      wAcc = static_cast<int32_t>(enforceBitWidth(wAcc, P_.VBits_));
      S_.y3_ = addWithoutOverflow(S_.y3_, wAcc, P_.VBits_);
    }
    else // neuron is absolute refractory
    {
      B_.spikes_.get_value(lag);  // clear buffer entry, ignore spike

      --S_.r_;
    }
   
    // threshold crossing
    if (S_.y3_ >= P_.V_th_)
    {
      // voltage logging
      B_.logger_.record_data(origin.get_steps()+lag);
      
      S_.r_ = V_.RefractoryCounts_;
      S_.y3_ = V_rest_;
        
      // EX: must compute spike time
      set_spiketime(Time::step(origin.get_steps()+lag+1));
        
      SpikeEvent se;
      network()->send(*this, se, lag);
    }
    else
    {
      // voltage logging
      B_.logger_.record_data(origin.get_steps()+lag);
    }

    // Ignore input current
    B_.currents_.get_value(lag);
  }
}                           
                     
void nest::iaf_psc_delta_int::handle(SpikeEvent & e)
{
  assert(e.get_delay() > 0);

  int32_t w = static_cast<int32_t>(round(e.get_weight()));
  if(enforceBitWidth(w, P_.wBits_) != w)
  {
    throw invalid_argument(
      "Synaptic weights must be integers within the range determined by the bit "
      "width of synaptic weights.");
  }

  int32_t wAcc = enforceBitWidth(w * e.get_multiplicity(), P_.wAccBits_);
  if(wAcc != w * e.get_multiplicity())
  {
    // The synaptic weight accumulator overflows.
    // Set its value to the value with the maximum possible absolute value and
    // the same sign as the synaptic weight.
    wAcc = (static_cast<int32_t>(-1) << (P_.wAccBits_ - 1));
    if(w >= 0)
      wAcc = (~wAcc);
  } 

  // EX: We must compute the arrival time of the incoming spike
  //     explicity, since it depends on delay and offset within
  //     the update cycle.  The way it is done here works, but
  //     is clumsy and should be improved.
  B_.spikes_.add_value(
    e.get_rel_delivery_steps(network()->get_slice_origin()),
    wAcc);
}

void nest::iaf_psc_delta_int::handle(CurrentEvent&)
{
  throw UnexpectedEvent();
}

void nest::iaf_psc_delta_int::handle(DataLoggingRequest &e)
{
  B_.logger_.handle(e);
}
 
} // namespace

