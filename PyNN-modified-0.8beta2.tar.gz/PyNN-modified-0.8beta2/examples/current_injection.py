"""
Injecting time-varying current into a cell.

There are four "standard" current sources in PyNN:

    - DCSource
    - ACSource
    - StepCurrentSource
    - NoisyCurrentSource

Any other current waveforms can be implemented using StepCurrentSource.

Usage:

"""

from pyNN.utility import get_simulator, normalized_filename

sim, options = get_simulator(("--plot-figure", "Plot the simulation results to a file", {"action": "store_true"}),

sim.setup()

cell = sim.create(IF_curr_exp(v_thresh=-55.0, tau_refrac=5.0))
current_source = sim.StepCurrentSource(times=[50.0, 110.0, 150.0, 210.0],
                                       amplitudes=[0.4, 0.6, -0.2, 0.2])
cell.inject(current_source)

filename = normalized_filename("Results", "current_injection", "pkl", simulator_name)
sim.record('v', cell, filename, annotations={'script_name': __file__})
sim.run(250.0)

sim.end()


if options.plot_figure:
    from pyNN.utility.plotting import Figure, Panel
    figure_filename = filename.replace("pkl", "png")
    Figure(
        # raster plot of the presynaptic neuron spike times
        Panel(